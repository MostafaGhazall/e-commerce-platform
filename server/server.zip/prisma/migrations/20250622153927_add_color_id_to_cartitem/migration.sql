-- AlterTable
ALTER TABLE "CartItem" ADD COLUMN     "colorId" TEXT;
