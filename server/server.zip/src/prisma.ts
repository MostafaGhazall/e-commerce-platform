import { PrismaClient } from "./generated/client";

const prisma = new PrismaClient();

export default prisma;
